/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.l = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };

/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};

/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};

/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 50);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * BetterDiscord Vendor Exports
 * Exports jQuery to be used in other classes
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var jquery = __webpack_require__(19);
var moment = __webpack_require__(46);
var react = __webpack_require__(20);
var reactdom = __webpack_require__(21);

module.exports = {
  jQuery: jquery,
  $: jquery,
  moment: moment,
  React: react,
  ReactDOM: reactdom
};

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = window.require('react');

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Events Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ISingleton = __webpack_require__(4);

var _require = __webpack_require__(47),
    EventEmitter = _require.EventEmitter;

var emitter = new EventEmitter();

var Events = function (_ISingleton) {
    _inherits(Events, _ISingleton);

    function Events() {
        _classCallCheck(this, Events);

        return _possibleConstructorReturn(this, (Events.__proto__ || Object.getPrototypeOf(Events)).call(this, "events"));
    }

    _createClass(Events, [{
        key: 'on',
        value: function on(eventName, callBack) {
            emitter.on(eventName, callBack);
        }
    }, {
        key: 'off',
        value: function off(eventName, callBack) {
            emitter.removeListener(eventName, callBack);
        }
    }, {
        key: 'emit',
        value: function emit() {
            emitter.emit.apply(emitter, arguments);
        }
    }]);

    return Events;
}(ISingleton);

module.exports = new Events();

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * BetterDiscord Modules Export
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Utils = __webpack_require__(6);
var Logger = __webpack_require__(9);
var IPC = __webpack_require__(5);
var cache = __webpack_require__(8);
var events = __webpack_require__(2);
var messageHandler = __webpack_require__(29);
var observer = __webpack_require__(30);
var reflection = __webpack_require__(14);
var renderer = __webpack_require__(32);
var settings = __webpack_require__(15);
var CssEditor = __webpack_require__(27);
var Emotes = __webpack_require__(28);
var PluginManager = __webpack_require__(31);

module.exports = {
    Utils: Utils,
    Logger: Logger,
    Cache: cache,
    Events: events,
    MessageHandler: messageHandler,
    Observer: observer,
    Reflection: reflection,
    Renderer: renderer,
    Settings: settings,
    IPC: IPC,
    CssEditor: CssEditor,
    Emotes: Emotes,
    PluginManager: PluginManager
};

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var instances = [];

var ISingleton = function ISingleton(name) {
    _classCallCheck(this, ISingleton);

    this.created_at = new Date();
    return instances[name] || (instances[name] = this);
};

module.exports = ISingleton;

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * BetterDiscord IPC Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

//Initialize new ipc instance
var _require = __webpack_require__(22),
    ipcRenderer = _require.ipcRenderer;

var ISingleton = __webpack_require__(4);
var Events = __webpack_require__(2);

var IPC = function (_ISingleton) {
    _inherits(IPC, _ISingleton);

    function IPC() {
        _classCallCheck(this, IPC);

        var _this = _possibleConstructorReturn(this, (IPC.__proto__ || Object.getPrototypeOf(IPC)).call(this, "ipcmodule"));

        var self = _this;
        if (self.initialized) return _possibleConstructorReturn(_this);
        self.initialized = true;
        self.register = {};
        ipcRenderer.on("bd-async", self.onMessage.bind(self));
        return _this;
    }

    _createClass(IPC, [{
        key: 'send',
        value: function send(message, cb) {
            var self = this;
            var id = Date.now() + Math.random();
            if (cb) self.register[id] = cb;
            ipcRenderer.send("bd-async", Object.assign({ "id": id }, message));
        }
    }, {
        key: 'sendSync',
        value: function sendSync(message) {
            return ipcRenderer.sendSync("bd-sync", message);
        }
    }, {
        key: 'onMessage',
        value: function onMessage(event, args) {
            var self = this;
            if (self.register[args.id]) {
                self.register[args.id](args);
                delete self.register[args.id];
                return; //Registered event
            }

            var command = args.command;


            switch (command) {
                case 'browser-event':
                    var _event = args.event;

                    Events.emit('browser-event', _event);
                    break;
            }
        }
    }, {
        key: 'on',
        value: function on(event, cb) {
            ipcRenderer.on(event, cb);
        }
    }]);

    return IPC;
}(ISingleton);

module.exports = new IPC();

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Utilities Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var fs = __webpack_require__(48);
var Cache = __webpack_require__(8);

var Utils = function () {
    function Utils() {
        _classCallCheck(this, Utils);
    }

    _createClass(Utils, [{
        key: 'tryParse',
        value: function tryParse(data) {
            try {
                return JSON.parse(data);
            } catch (err) {
                console.log(err);
                return null;
            }
        }
    }, {
        key: 'fileExistsSync',
        value: function fileExistsSync(path) {
            try {
                return fs.statSync(path).isFile();
            } catch (err) {
                return false;
            }
        }
    }, {
        key: 'readFileSync',
        value: function readFileSync(path, encoding) {
            if (!this.fileExistsSync(path)) return null;
            return fs.readFileSync(path, encoding || 'utf8');
        }
    }, {
        key: 'writeFileSync',
        value: function writeFileSync(path, data, encoding) {
            try {
                fs.writeFileSync(path, data, encoding || 'utf8');
                return true;
            } catch (err) {
                return false;
            }
        }
    }, {
        key: 'readDir',
        value: function readDir(path, cb) {
            fs.readdir(path, function (err, files) {
                if (err) {
                    cb(null);
                    return;
                }
                cb(files);
            });
        }
    }]);

    return Utils;
}();

module.exports = new Utils();

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Checkbox Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CCheckBox = function (_Component) {
    _inherits(CCheckBox, _Component);

    function CCheckBox(props) {
        _classCallCheck(this, CCheckBox);

        var _this = _possibleConstructorReturn(this, (CCheckBox.__proto__ || Object.getPrototypeOf(CCheckBox)).call(this, props));

        _this.onClick = _this.onClick.bind(_this);
        _this.onChange = _this.onChange.bind(_this);
        _this.setInitialState();
        return _this;
    }

    _createClass(CCheckBox, [{
        key: 'setInitialState',
        value: function setInitialState() {
            this.state = {
                checked: this.props.checked || this.props.enabled
            };
        }
    }, {
        key: 'render',
        value: function render() {

            if (!this.props.li) {
                return React.createElement(
                    'div',
                    { onClick: this.onClick, className: 'checkbox' },
                    React.createElement(
                        'div',
                        { className: 'checkbox-inner' },
                        React.createElement('input', { onChange: this.onChange, checked: this.state.checked, type: 'checkbox' }),
                        React.createElement('span', null)
                    ),
                    React.createElement(
                        'span',
                        null,
                        this.props.text
                    )
                );
            }

            return React.createElement(
                'span',
                null,
                React.createElement(
                    'li',
                    null,
                    React.createElement(
                        'div',
                        { onClick: this.onClick, className: 'checkbox' },
                        React.createElement(
                            'div',
                            { className: 'checkbox-inner' },
                            React.createElement('input', { onChange: this.onChange, checked: this.state.checked, type: 'checkbox' }),
                            React.createElement('span', null)
                        ),
                        React.createElement(
                            'span',
                            null,
                            this.props.text
                        )
                    )
                ),
                this.props.helptext !== undefined && React.createElement(
                    'li',
                    null,
                    React.createElement(
                        'div',
                        { className: 'help-text' },
                        this.props.helptext,
                        this.props.link !== undefined && React.createElement(
                            'a',
                            { style: { display: "block" }, href: this.props.link.href, target: '_blank' },
                            this.props.link.text
                        )
                    )
                )
            );
        }
    }, {
        key: 'onClick',
        value: function onClick() {
            if (!this.props.onChange(this.props.id, !this.state.checked)) return;
            this.setState({
                checked: !this.state.checked
            });
        }
    }, {
        key: 'onChange',
        value: function onChange() {}
    }]);

    return CCheckBox;
}(_React.Component);

exports.default = CCheckBox;

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Cache Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Cache = function () {
    function Cache(persistent) {
        _classCallCheck(this, Cache);

        this.cache = {};
        if (!persistent) {
            setInterval(this.clear.bind(this), 60000);
        }
    }

    _createClass(Cache, [{
        key: 'add',
        value: function add(id, o) {
            this.cache[id] = o;
        }
    }, {
        key: 'cached',
        value: function cached(id) {
            return id in this.cache;
        }
    }, {
        key: 'clear',
        value: function clear() {
            this.cache = {};
        }
    }]);

    return Cache;
}();

module.exports = Cache;

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Logger Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Logger = function () {
    function Logger() {
        _classCallCheck(this, Logger);
    }

    _createClass(Logger, null, [{
        key: 'log',
        value: function log(moduleName, message, level) {
            var _console;

            (_console = console).log.apply(_console, ['%c[%cBetter%cDiscord%c:' + moduleName + '%c]%c ' + message + ' '].concat(_toConsumableArray(this.style(level || 'info'))));
        }
    }, {
        key: 'style',
        value: function style(level) {
            return {
                'info': ['padding: 1px; color: #FFFFFF;', 'padding: 1px; color: #3E82E5;', 'padding: 1px; color: #FFFFFF;', 'padding: 1px; color: #FFFFFF;', 'padding: 1px; color: #FFFFFF;', 'padding: 1px; color: #FFFFFF;'],
                'warn': ['padding: 1px; color: #FFFFFF; background: #332a00; border-color: #665500; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #3E82E5; background: #332a00; border-color: #665500; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #FFFFFF; background: #332a00; border-color: #665500; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #FFFFFF; background: #332a00; border-color: #665500; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #FFFFFF; background: #332a00; border-color: #665500; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #fdda9c; background: #332a00; border-color: #665500; border-width: 1px 0 1px 0; border-style: solid;'],
                'err': ['padding: 1px; color: #FFFFFF; background: #280000; border-color: #5b0000; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #3E82E5; background: #280000; border-color: #5b0000; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #FFFFFF; background: #280000; border-color: #5b0000; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #FFFFFF; background: #280000; border-color: #5b0000; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #FFFFFF; background: #280000; border-color: #5b0000; border-width: 1px 0 1px 0; border-style: solid;', 'padding: 1px; color: #d56666; background: #280000; border-color: #5b0000; border-width: 1px 0 1px 0; border-style: solid;']
            }[level];
        }
    }]);

    return Logger;
}();

module.exports = Logger;

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Channel Struct
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Channel = function Channel(data) {
    _classCallCheck(this, Channel);

    this.id = data.guild_id;
    this.name = data.name;
    this.topic = data.topic;
};

module.exports = Channel;

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * BetterDiscord Api Structs Export
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Channel = __webpack_require__(10);
var Guild = __webpack_require__(25);
var Message = __webpack_require__(26);
var Role = __webpack_require__(12);
var User = __webpack_require__(13);

module.exports = {
  Channel: Channel,
  Guild: Guild,
  Message: Message,
  Role: Role,
  User: User
};

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Role Struct
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Role = function Role(data) {
    _classCallCheck(this, Role);

    this.color = data.color;
    this.colorString = data.colorString;
    this.hoist = data.hoist;
    this.id = data.id;
    this.managed = data.managed;
    this.mentionable = data.mentionable;
    this.name = data.name;
    this.originalPosition = data.originalPosition;
    this.permissions = data.permissions;
    this.position = data.position;
};

module.exports = Role;

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord User Struct
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var User = function User(data) {
    _classCallCheck(this, User);

    this.id = data.id;
    this.username = data.username;
    this.discriminator = data.discriminator;
    this.mobile = data.mobile;
    this.premium = data.premium;
    this.verified = data.verified;
    this.avatar = data.avatar;
    this.avatar_url = "https://cdn.discordapp.com/avatars/" + data.id + "/" + data.avatar;
    this.bot = data.bot;
    this.createdAt = data.createdAt;
};

module.exports = User;

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord React "Reflection" Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var _require = __webpack_require__(0),
    $ = _require.$;

var Reflection = function () {
    function Reflection() {
        _classCallCheck(this, Reflection);
    }

    _createClass(Reflection, [{
        key: 'getReactInternalInstance',
        value: function getReactInternalInstance(o) {
            if (!o) return null;
            if (o instanceof $) o = o.last()[0];
            var instance = o[Object.keys(o).filter(function (key) {
                return key.indexOf("__reactInternalInstance") !== -1;
            })];
            if (!instance) return null;
            return instance;
        }
    }, {
        key: 'getProps',
        value: function getProps(o) {
            if (o.props) return o.props;
            if (!o[0]) return null;
            if (o[0].props) return o[0].props;
            return null;
        }
    }, {
        key: 'getChildren',
        value: function getChildren(o) {
            if (o.children) return o.children;
            if (!o[0]) return null;
            if (o[0].children) return o[0].children;
            return null;
        }
    }, {
        key: 'next',
        value: function next(o) {
            return o.props ? { t: 'p', p: o.props } : o.children ? { t: 'c', c: o.children } : null;
        }
    }, {
        key: 'scan',
        value: function scan(t, o, p) {
            var self = this;
            if (!o) return null;
            if (self.ic(o, $)) o = self.getReactInternalInstance(o);

            if (o.hasOwnProperty(p)) return o[p];

            switch (t) {
                case 'p':
                    return self.sp(o, p);
                case 's':
                    return self.ss(o, p);
            }
        }
    }, {
        key: 'sp',
        value: function sp(o, p) {
            if (!o) return null;
            var self = this;

            if (o.hasOwnProperty(p)) return o[p];
            if (o.hasOwnProperty('_currentElement')) o = o._currentElement;

            var n = self.next(o);
            if (!n) return null;

            return {
                'p': self.sp(n.p, p),
                'c': function () {
                    if (!self.ic(n.c, Array)) return self.sp(n.c, p);
                    for (var i = 0; i < n.c.length; i++) {
                        var c = n.c[i];
                        if (self.ic(c, Array)) {
                            var r = self.sp(c[0], p);
                            if (r) {
                                return r;
                            }
                        } else {
                            var _r = self.sp(c, p);
                            if (_r) {
                                return _r;
                            }
                        }
                    }
                    return null;
                }()
            }[n.t];
        }
    }, {
        key: 'ss',
        value: function ss(o, p) {
            if (!o) return null;
            var self = this;
            if (o.hasOwnProperty(p)) return o[p];
            if (o.hasOwnProperty('_renderedChildren')) o = o._renderedChildren;
            if (o.hasOwnProperty('_instance')) return self.ss(o._instance, p);
            if (o.hasOwnProperty('state')) return self.ss(o.state, p);

            if (!self.ic(o, Object)) return null;

            var os = o[Object.keys(o).filter(function (k) {
                if (!o[k].hasOwnProperty('_instance')) return false;
                var instance = o[k]._instance;
                if (!instance.hasOwnProperty('state')) return false;
                return instance.state;
            })];

            if (os) {
                return self.ss(os, p);
            }

            return null;
        }
    }, {
        key: 'ic',
        value: function ic(o, t) {
            return o instanceof t;
        }
    }, {
        key: 'getFirstInstance',
        value: function getFirstInstance(o) {
            var self = this;

            o = self.getReactInternalInstance(o);
            if (!o) return null;

            if (!o.hasOwnProperty("_renderedChildren")) return null;
            var rc = o._renderedChildren;
            var f = rc[Object.keys(rc)[0]];

            if (!f.hasOwnProperty("_instance")) return null;
            return f._instance;
        }
    }, {
        key: 'overrideFunction',
        value: function overrideFunction(s, o, n) {
            s = s || this;
            return function () {
                for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
                    args[_key] = arguments[_key];
                }

                n.apply(s, args);
                o.apply(s, args);
            };
        }
    }, {
        key: 'getMessageProps',
        value: function getMessageProps(node, cb) {
            var self = this;
            var instance = this.getReactInternalInstance(node);
            if (instance === null) {
                cb(null);
                return;
            }

            try {
                var props = self.getProps(instance._currentElement);
                var children = self.getChildren(props);

                //Check the last child first
                if (children[0].length > 1) {
                    var lastChild = children[0][children[0].length - 1];
                    if (self.typecheck(lastChild, "object")) {
                        var _props = self.getProps(lastChild);
                        if (_props !== null) {
                            cb(_props);
                            return;
                        }
                    }
                }

                //If last child is not valid go on and check all of them
                children.some(function (child, index, array) {
                    if (!child) {
                        if (index === array.length - 1) {
                            cb(null);
                            return true;
                        }
                        return false;
                    }
                    if (!self.typecheck(child, "object")) {
                        if (index === array.length - 1) {
                            cb(null);
                            return true;
                        }
                        return false;
                    }

                    var props = self.getProps(child);
                    if (props !== null) {
                        cb(props);
                        return true;
                    }
                });
            } catch (err) {
                cb(null);
                return;
            }
        }
    }, {
        key: 'typecheck',
        value: function typecheck(e) {
            for (var _len2 = arguments.length, types = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
                types[_key2 - 1] = arguments[_key2];
            }

            return types.some(function (type) {
                return (typeof e === 'undefined' ? 'undefined' : _typeof(e)) === type;
            });
        }
    }]);

    return Reflection;
}();

module.exports = new Reflection();

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Settings Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var IPC = __webpack_require__(5);
var Utils = __webpack_require__(6);
var defaultSettings = {
    "core": [{
        "key": "voice-disconnect",
        "text": "Voice Disconnect",
        "helptext": "Disconnect from voice server when Discord closes",
        "enabled": false
    }, {
        "key": "developer-mode",
        "text": "Developer Mode",
        "helptext": "BetterDiscord developer mode",
        "enabled": false
    }],
    "ui": [{
        "key": "public-servers",
        "text": "Public Servers",
        "helptext": "Display public servers button",
        "enabled": false
    }, {
        "key": "minimal-mode",
        "text": "Minimal Mode",
        "helptext": "Hide elements and reduce size of certain elements",
        "enabled": false
    }, {
        "key": "voice-mode",
        "text": "Voice Mode",
        "helptext": "Only show voice chat",
        "enabled": false
    }, {
        "key": "hide-channels",
        "text": "Hide Channels",
        "helptext": "Hide server channels in minimal mode",
        "enabled": false
    }, {
        "key": "dark-mode",
        "text": "Dark Mode(wip)",
        "helptext": "Make certain elements dark by default",
        "enabled": false
    }, {
        "key": "timestamp",
        "text": "24 Hour Timestamps",
        "helptext": "Replace 12 hour timestamps with proper ones",
        "enabled": false
    }, {
        "key": "coloured-text",
        "text": "Coloured Text",
        "helptext": "Make text colour the same as role colour",
        "enabled": false
    }],
    "emotes": [{
        "key": "twitch-emotes",
        "text": "Twitch Emotes",
        "helptext": "Show Twitch emotes",
        "enabled": false
    }, {
        "key": "ffz-emotes",
        "text": "FrankerFaceZ Emotes",
        "helptext": "Show FrankerFaceZ emotes",
        "enabled": false
    }, {
        "key": "bttv-emotes",
        "text": "BetterTTV Emotes",
        "helptext": "Show BetterTTV emotes",
        "enabled": false
    }, {
        "key": "emote-menu",
        "text": "Emote Menu",
        "helptext": "Show Twitch/Favourite emotes in emote menu",
        "enabled": false
    }, {
        "key": "emoji-menu",
        "text": "Emoji Menu",
        "helptext": "Show Discord emoji menu",
        "enabled": false
    }, {
        "key": "emote-autocap",
        "text": "Emote Auto Capitalization",
        "helptext": "Automatically capitalize emotes as you type",
        "enabled": false
    }, {
        "key": "emote-tooltips",
        "text": "Emote Tooltips",
        "helptext": "Show emote tooltips when you hover over them",
        "enabled": false
    }, {
        "key": "emote-modifiers",
        "text": "Emote Modifiers",
        "helptext": "Enable emote modifiers",
        "enabled": false
    }]
};

var SettingsModule = function () {
    function SettingsModule() {
        _classCallCheck(this, SettingsModule);
    }

    _createClass(SettingsModule, null, [{
        key: 'init',
        value: function init() {
            var self = this;
            if (self.filePath !== undefined) {
                //TODO replace with Logger
                console.log("Attempt to reinitialize SettingsModule has been blocked");
                return;
            }

            var getSettings = IPC.sendSync({ 'command': 'getconfig' });
            self.settings = getSettings.data;

            self.load();
        }
    }, {
        key: 'load',
        value: function load() {
            var self = this;
            var read = Utils.readFileSync(self.settings.dataPath + '/user.settings.json');

            if (!read) {
                self.userSettings = defaultSettings;
                return;
            }

            var settings = Utils.tryParse(read);

            self.userSettings = settings || defaultSettings;
        }
    }, {
        key: 'save',
        value: function save() {
            var self = this;
            if (!Utils.writeFileSync(self.settings.dataPath + '/user.settings.json', JSON.stringify(self.userSettings))) {
                //TODO replace with Logger
                console.log("Failed to write settings file!");
            }
        }
    }, {
        key: 'getSettings',
        value: function getSettings(key) {
            return this.userSettings[key];
        }
    }, {
        key: 'getCoreSetting',
        value: function getCoreSetting(key) {
            return this.getSetting("core", key);
        }
    }, {
        key: 'getUiSetting',
        value: function getUiSetting(key) {
            return this.getSetting("ui", key);
        }
    }, {
        key: 'getEoteSetting',
        value: function getEoteSetting(key) {
            return this.getSetting("emotes", key);
        }
    }, {
        key: 'getSetting',
        value: function getSetting(sub, key) {
            return this.userSettings[sub].filter(function (value) {
                return value.key === key;
            })[0];
        }
    }, {
        key: 'setCoreSetting',
        value: function setCoreSetting(key, enabled) {
            this.setSetting("core", key, enabled);
        }
    }, {
        key: 'setUiSetting',
        value: function setUiSetting(key, enabled) {
            this.setSetting("ui", key, enabled);
        }
    }, {
        key: 'setEmoteSetting',
        value: function setEmoteSetting(key, enabled) {
            this.setSetting("emotes", key, enabled);
        }
    }, {
        key: 'setSetting',
        value: function setSetting(sub, key, enabled) {
            this.getSetting(sub, key).enabled = enabled;
            this.save();
        }
    }, {
        key: 'getCoreSettings',
        get: function get() {
            return this.getSettings("core");
        }
    }, {
        key: 'getUiSettings',
        get: function get() {
            return this.getSettings("ui");
        }
    }, {
        key: 'getEmoteSettings',
        get: function get() {
            return this.getSettings("emotes");
        }
    }]);

    return SettingsModule;
}();

module.exports = SettingsModule;

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord ContextMenu Checkbox Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CContextMenuCheckBox = function (_Component) {
    _inherits(CContextMenuCheckBox, _Component);

    function CContextMenuCheckBox(props) {
        _classCallCheck(this, CContextMenuCheckBox);

        return _possibleConstructorReturn(this, (CContextMenuCheckBox.__proto__ || Object.getPrototypeOf(CContextMenuCheckBox)).call(this, props));
    }

    _createClass(CContextMenuCheckBox, [{
        key: 'render',
        value: function render() {
            return React.createElement(
                'div',
                { className: 'checkbox' },
                React.createElement(
                    'div',
                    { className: 'checkbox-inner' },
                    React.createElement('input', { type: 'checkbox' }),
                    React.createElement('span', null)
                ),
                React.createElement('span', null)
            );
        }
    }]);

    return CContextMenuCheckBox;
}(_React.Component);

exports.default = CContextMenuCheckBox;

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Components Export
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var _button = __webpack_require__(37);

var _button2 = _interopRequireDefault(_button);

var _checkbox = __webpack_require__(7);

var _checkbox2 = _interopRequireDefault(_checkbox);

var _checkboxGroup = __webpack_require__(38);

var _checkboxGroup2 = _interopRequireDefault(_checkboxGroup);

var _link = __webpack_require__(18);

var _link2 = _interopRequireDefault(_link);

var _pluginlist = __webpack_require__(41);

var _pluginlist2 = _interopRequireDefault(_pluginlist);

var _protip = __webpack_require__(42);

var _protip2 = _interopRequireDefault(_protip);

var _settingsPanel = __webpack_require__(43);

var _settingsPanel2 = _interopRequireDefault(_settingsPanel);

var _contextMenu = __webpack_require__(39);

var _contextMenu2 = _interopRequireDefault(_contextMenu);

var _contextMenuCheckbox = __webpack_require__(16);

var _contextMenuCheckbox2 = _interopRequireDefault(_contextMenuCheckbox);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = {
    CButton: _button2.default,
    CCheckBox: _checkbox2.default,
    CCheckboxGroup: _checkboxGroup2.default,
    CLink: _link2.default,
    CPluginList: _pluginlist2.default,
    CProTip: _protip2.default,
    CSettingsPanel: _settingsPanel2.default,
    CContextMenu: _contextMenu2.default,
    CContextMenuCheckBox: _contextMenuCheckbox2.default
};

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Link Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CLink = function (_Component) {
    _inherits(CLink, _Component);

    function CLink(props) {
        _classCallCheck(this, CLink);

        return _possibleConstructorReturn(this, (CLink.__proto__ || Object.getPrototypeOf(CLink)).call(this, props));
    }

    _createClass(CLink, [{
        key: 'render',
        value: function render() {
            var _this2 = this;

            return React.createElement(
                'a',
                { style: this.props.style, onClick: function onClick() {
                        return _this2.props.onClick(_this2.props.id);
                    } },
                this.props.text
            );
        }
    }]);

    return CLink;
}(_React.Component);

exports.default = CLink;

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord jQuery vendor
 * Exports jQuery to be used in other classes
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var jQueryInstance = window._bd.jQuery;

module.exports = jQueryInstance;

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord React vendor
 * Exports React to be used in other classes
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var ReactInstance = __webpack_require__(1);

module.exports = ReactInstance;

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord react-dom vendor
 * Exports react-dom to be used in other classes
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var ReactDOMInstance = __webpack_require__(49);

module.exports = ReactDOMInstance;

/***/ }),
/* 22 */
/***/ (function(module, exports) {

module.exports = window.require('electron');

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Api
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */

var _require = __webpack_require__(11),
    Message = _require.Message,
    Channel = _require.Channel,
    User = _require.User,
    Guild = _require.Guild,
    Role = _require.Role;

var _require2 = __webpack_require__(3),
    Reflection = _require2.Reflection;

var _require3 = __webpack_require__(0),
    $ = _require3.$;

var Api = function () {
    function Api() {
        _classCallCheck(this, Api);

        this.structs = {
            Message: Message,
            Channel: Channel,
            User: User,
            Guild: Guild,
            Role: Role
        };
    }

    _createClass(Api, [{
        key: 'getCurrentGuild',
        value: function getCurrentGuild() {
            var selectedGuild = $(".guild.selected");
            if (!selectedGuild) return null;
            var instance = Reflection.getReactInternalInstance(selectedGuild.last()[0]);
            if (!instance) return null;

            try {

                var props = Reflection.getProps(instance._currentElement);
                var children = Reflection.getChildren(props);

                var d = children[0].props.children.props.guild;

                return new Guild(d);
            } catch (err) {
                console.log(err);
                return null;
            }
        }
    }]);

    return Api;
}();

module.exports = new Api();

function next(o) {
    return o.props ? { type: 'props', props: o.props } : o.children ? { type: 'children', children: o.children } : null;
}

function scan(o, prop) {
    if (!o) return null;
    if (o.hasOwnProperty(prop)) return o[prop];
    var n = next(o);
    if (!n) return null;

    switch (n.type) {
        case 'props':
            return scan(n.props, prop);
        case 'children':
            if (!(n.children instanceof Array)) return scan(n.children, prop);

            return n.children.map(function (value) {
                var s = scan(value, prop);
                if (s) return s;
            });

    }
}

function iterate(obj, stack) {
    for (var property in obj) {
        if (obj.hasOwnProperty(property)) {
            if (_typeof(obj[property]) == "object") {
                iterate(obj[property], stack + '.' + property);
            } else {
                console.log(property + "   " + obj[property]);
            }
        }
    }
}

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * BetterDiscord UI Export
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var settingsPanel = __webpack_require__(45);
var contextMenu = __webpack_require__(44);

module.exports = {
  SettingsPanel: settingsPanel,
  ContextMenu: contextMenu
};

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Guild Struct
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Role = __webpack_require__(12);

var Guild = function Guild(data) {
    _classCallCheck(this, Guild);

    this.afkChannelId = data.afkChannelId;
    this.afkTimeout = data.afkTimeout;
    this.icon = data.icon;
    this.id = data.id;
    this.joinedAt = data.joinedAt;
    this.large = data.large;
    this.name = data.name;
    this.ownerId = data.ownerId;
    this.region = data.region;
    this.icon_url = 'https://cdn.discordapp.com/icons/' + this.id + '/' + this.icon;

    this.roles = Object.values(data.roles).map(function (value) {
        return new Role(value);
    });
};

module.exports = Guild;

/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Message Struct
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Channel = __webpack_require__(10);
var User = __webpack_require__(13);

var Message = function Message(data) {
    _classCallCheck(this, Message);

    var message = data.message,
        channel = data.channel;
    var author = message.author;

    this.state = message.state;
    this.id = message.id;
    this.content = message.content;
    this.timestamp = message.timestamp._d || message.timestamp._i;
    this.mentioned = message.mentioned;
    this.mentions = [];
    this.pinned = message.pinned;
    this.embeds = [];
    this.tts = message.tts;
    this.mentionEveryone = message.mentionEveryone;
    this.attachments = [];
    this.blocked = message.blocked;
    this.nick = message.nick;
    this.author = new User(author);
    this.channel = new Channel(channel);
};

module.exports = Message;

/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord CSS Editor Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(22),
    remote = _require.remote;

var ISingleton = __webpack_require__(4);
var IPC = __webpack_require__(5);

var _require2 = __webpack_require__(0),
    $ = _require2.$;

var CssEditor = function (_ISingleton) {
    _inherits(CssEditor, _ISingleton);

    function CssEditor() {
        _classCallCheck(this, CssEditor);

        var _this = _possibleConstructorReturn(this, (CssEditor.__proto__ || Object.getPrototypeOf(CssEditor)).call(this, "css-editor"));

        var self = _this;
        if (self.editor) return _possibleConstructorReturn(_this);
        self.editor = {
            open: false,
            options: {
                'frame': false,
                'minWidth': 780,
                'minHeight': 400
            }
        };
        $("head").append('<style id="customcss"></style>');

        IPC.on('css-editor', function (sender, args) {
            var command = args.command;

            switch (command) {
                case 'update-css':
                    var css = args.css;

                    self.updateCss(css);
                    break;
            }
        });

        IPC.send({ 'command': 'getconfig' }, function (data) {
            var dataPath = data.data.dataPath;

            self.dataPath = dataPath;
        });
        return _this;
    }

    _createClass(CssEditor, [{
        key: 'updateCss',
        value: function updateCss(data) {
            $("#customcss").text(data);
        }
    }, {
        key: 'setExEditorCss',
        value: function setExEditorCss(data) {
            var self = this;
            if (self.editor.window) {
                self.editor.window.webContents.send('set-css', data);
            }
        }
    }, {
        key: 'open',
        value: function open() {
            var self = this;
            if (self.editor.open || self.editor.window) {
                self.editor.window.focus();
                self.editor.window.flashFrame(true);
                return;
            }

            self.editor.window = new remote.BrowserWindow(self.editor.options);
            self.editor.open = true;
            self.loadURL('file://' + self.dataPath + '/csseditor/index.html');
            self.editor.window.on('close', self.onClose.bind(self));
            self.editor.window.on('resize', self.onResize.bind(self));
            self.editor.window.on('move', self.onMove.bind(self));
        }
    }, {
        key: 'loadURL',
        value: function loadURL(url) {
            var self = this;
            if (!self.editor.window) return;
            self.editor.window.loadURL(url);
        }
    }, {
        key: 'onClose',
        value: function onClose() {
            var self = this;
            self.editor.open = false;
            self.editor.window = null;
        }
    }, {
        key: 'onResize',
        value: function onResize() {
            var self = this;

            var _self$editor$window$g = self.editor.window.getBounds(),
                width = _self$editor$window$g.width,
                height = _self$editor$window$g.height;

            self.editor.options.width = width;
            self.editor.options.height = height;
        }
    }, {
        key: 'onMove',
        value: function onMove() {
            var self = this;

            var _self$editor$window$g2 = self.editor.window.getBounds(),
                x = _self$editor$window$g2.x,
                y = _self$editor$window$g2.y;

            self.editor.options.x = x;
            self.editor.options.y = y;
        }
    }]);

    return CssEditor;
}(ISingleton);

module.exports = new CssEditor();

/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Emote Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Events = __webpack_require__(2);

var Emotes = function () {
    function Emotes() {
        _classCallCheck(this, Emotes);

        var self = this;

        Events.on('new-message', function (message) {
            self.inspectMessage(messaage);
        });
    }

    _createClass(Emotes, [{
        key: 'inspectMessage',
        value: function inspectMessage(message) {}
    }]);

    return Emotes;
}();

module.exports = Emotes;

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Message Handler Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Cache = __webpack_require__(8);
var Events = __webpack_require__(2);
var Reflection = __webpack_require__(14);

var _require = __webpack_require__(11),
    Message = _require.Message;

var _require2 = __webpack_require__(0),
    $ = _require2.$,
    moment = _require2.moment;

var MessageHandler = function () {
    function MessageHandler() {
        var _this = this;

        _classCallCheck(this, MessageHandler);

        this.messageCache = new Cache();
        Events.on('mutation', function (mutation) {
            return _this.handler(mutation);
        });
    }

    _createClass(MessageHandler, [{
        key: 'handler',
        value: function handler(mutation) {
            var self = this;
            //Check that mutation is a message
            if (mutation.target.classList.length !== 2) return;
            if (mutation.target.classList[1] !== "messages" && mutation.addedNodes.length) return;

            //We grab the last message instead of checking all of them for better performance 
            var lastMessage = $(".comment").last()[0];
            Reflection.getMessageProps(lastMessage, function (msg) {
                if (msg === null) return;

                var id = msg.message.id;


                if (self.messageCache.cached(id)) return;

                var message = new Message(msg);
                if (moment.duration(Date.now() - new Date(message.timestamp))._milliseconds >= 3000) return;

                self.messageCache.add(id, message);

                Events.emit('new-message', message);
            });
        }
    }]);

    return MessageHandler;
}();

module.exports = MessageHandler;

/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Observer Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ISingleton = __webpack_require__(4);
var Events = __webpack_require__(2);

var _require = __webpack_require__(0),
    $ = _require.$;

var ObserverModule = function (_ISingleton) {
    _inherits(ObserverModule, _ISingleton);

    function ObserverModule() {
        _classCallCheck(this, ObserverModule);

        return _possibleConstructorReturn(this, (ObserverModule.__proto__ || Object.getPrototypeOf(ObserverModule)).call(this, "observer"));
    }

    _createClass(ObserverModule, [{
        key: 'observe',
        value: function observe(options) {
            var self = this;
            if (self.observing) return;
            self.observing = true;
            self.observer = new MutationObserver(function (mutations) {
                return mutations.map(function (value) {
                    return self.mutationHandler(value);
                });
            });
            self.observer.observe(document, options);
        }
    }, {
        key: 'mutationHandler',
        value: function mutationHandler(mutation) {

            var self = this;
            Events.emit("mutation", mutation);
            self.settingsPanel(mutation);
            self.contextMenu(mutation);
        }
    }, {
        key: 'contextMenu',
        value: function contextMenu(mutation) {
            if (mutation.type !== 'childList') return;
            if (!mutation.addedNodes) return;
            if (mutation.addedNodes.length <= 0) return;
            var firstChild = mutation.addedNodes[0];
            if (!firstChild.classList) return;
            if (firstChild.classList.length !== 2) return;
            if (firstChild.classList[0] !== 'context-menu') return;

            Events.emit('context-menu', $(".context-menu").first());
        }
    }, {
        key: 'settingsPanel',
        value: function settingsPanel(mutation) {
            if (mutation.type !== 'childList') return;
            if (!mutation.addedNodes) return;
            if (mutation.addedNodes.length <= 0) return;
            var $userSettingsModal = $(mutation.addedNodes[0]).find(".user-settings-modal");
            if ($userSettingsModal.length <= 0) return;
            Events.emit('user-settings-modal', $userSettingsModal);
        }
    }]);

    return ObserverModule;
}(ISingleton);

module.exports = new ObserverModule();

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Plugin Manager
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
*/

var _require = __webpack_require__(34),
    Plugin = _require.Plugin,
    PluginApi = _require.PluginApi,
    PluginStorage = _require.PluginStorage;

var _require2 = __webpack_require__(0),
    jQuery = _require2.jQuery,
    React = _require2.React;

var IPC = __webpack_require__(5);

var Utils = __webpack_require__(6);
var Logger = __webpack_require__(9);
var Events = __webpack_require__(2);
var Settings = __webpack_require__(15);

var Plugins = {};

var Vendor = {
    'jQuery': jQuery,
    'React': React
};

//Heuristic keyword ban
var blockedKeywords = {
    'token': 'ACCESS USER TOKEN',
    'localstorage': 'ACCESS LOCALSTORAGE',
    'require': 'REQUIRE MODULE',
    'iframe': 'CREATE IFRAMES',
    'eval': 'EVALUATE CODE'
};

var authorizedPlugins = [];

var PluginManager = function () {
    function PluginManager() {
        _classCallCheck(this, PluginManager);
    }

    _createClass(PluginManager, null, [{
        key: 'init',
        value: function init() {
            var self = this;
            self.pluginPath = Settings.settings.basePath + '/plugins';
            self.loadPlugins(function () {});
        }
    }, {
        key: 'loadPlugins',
        value: function loadPlugins(cb) {
            var self = this;
            Utils.readDir(self.pluginPath, function (files) {
                if (!files) {
                    cb(self.plugins);
                    return;
                }
                files.forEach(function (file) {
                    self.loadPluginv2(file, false, true);
                    //if (!file.endsWith('.plugin.js')) return;
                    //self.loadPlugin(file.replace('.plugin.js', ''));
                });

                cb(self.plugins);
            });
        }
    }, {
        key: 'loadPluginv2',
        value: function loadPluginv2(name, reload, all) {
            var self = this;

            var basePath = self.pluginPath + '/' + name;

            if (self.plugins.hasOwnProperty(name) && !reload) {
                if (!all) Logger.log('PluginManager', 'Attempted to load already loaded plugin: ' + name, 'warn');
                return;
            }

            var config = Utils.tryParse(Utils.readFileSync(basePath + '/config.json'));

            if (!config) {
                Logger.log('PluginManager', 'Failed to load config for: ' + name, 'err');
                return;
            }

            Utils.readDir(basePath, function (files) {
                var pluginFile = files.find(function (file) {
                    return file.endsWith('.js');
                });
                if (!self.validatePlugin(basePath + '/' + pluginFile)) return;

                if (reload) delete window.require.cache[window.require.resolve(basePath + '/' + pluginFile)];

                var BD = {
                    'Api': new PluginApi(config.info),
                    'Storage': new PluginStorage(basePath, config.defaultSettings),
                    'Events': Events
                };

                var plugin = null;
                var pluginInstance = null;

                try {
                    plugin = window.require(basePath + '/' + pluginFile)(Plugin, BD, Vendor);
                    pluginInstance = new plugin(config.info);
                } catch (err) {
                    Logger.log('PluginManager', 'Failed to load plugin: ' + name + ' - ' + err.message, 'err');
                    console.log(err.stack);
                    return;
                }

                pluginInstance.internal = {
                    'storage': BD.Storage,
                    'path': name
                };

                Plugins[config.info.name] = pluginInstance;

                if (pluginInstance.internal.storage.getSetting('enabled')) pluginInstance.onStart();
            });
        }
    }, {
        key: 'loadPlugin',
        value: function loadPlugin(name, reload) {
            var self = this;

            if (self.plugins.hasOwnProperty(name) && !reload) return;

            var path = self.pluginPath + '/' + name + '.plugin.js';

            if (!self.validatePlugin(path)) return;

            if (reload) delete window.require.cache[window.require.resolve(path)];

            var plugin = null;
            var pluginInstance = null;
            try {
                plugin = window.require(path)(Plugin);
                pluginInstance = new plugin();
            } catch (err) {
                Logger.log('PluginLoader', 'Failed to load plugin: ' + name + ' - ' + err.message, 'err');
                console.log(err.stack);
                return;
            }

            pluginInstance.id = name;

            Plugins[name] = pluginInstance;

            var storage = new PluginStorage({ 'basePath': self.pluginPath, 'name': name, 'defaults': pluginInstance.defaultConfig });
            storage.load();

            pluginInstance.onLoad({
                'Api': new PluginApi(pluginInstance.props),
                'Vendor': Vendor,
                'Storage': storage,
                'Events': Events
            });

            pluginInstance.internal = {
                'storage': storage
            };

            if (!storage.getSetting('enabled')) storage.setSetting('enabled', false);
            if (storage.getSetting('enabled')) pluginInstance.onStart();

            return pluginInstance;
        }
    }, {
        key: 'validatePlugin',
        value: function validatePlugin(path) {
            var pluginData = Utils.readFileSync(path);
            if (!pluginData) {
                Logger.log('PluginLoader', 'Attempted to load a plugin that does not seem to exist: ' + path, 'warn');
                return false;
            }
            pluginData = pluginData.toLowerCase();

            if (Object.keys(blockedKeywords).some(function (key) {
                if (pluginData.indexOf(key) !== -1) {
                    Logger.log('PluginLoader', 'BLOCKED LOADING OF PLUGIN ATTEMPTING TO ' + blockedKeywords[key], 'err');
                    return true;
                }
            })) return false;

            //HASH VALIDATION IS DISABLED DURING DEVELOPMENT
            /* let hash = IPC.sendSync({ 'command': 'md5', 'data': path }).data;
             if (!authorizedPlugins.includes(hash)) {
                 Logger.log('PluginLoader', 'BLOCKED LOADING OF UNAUTHORIZED PLUGIN', 'err');
                 return false;
             }*/

            return true;
        }
    }, {
        key: 'reloadPlugin',
        value: function reloadPlugin(id) {
            if (!Plugins.hasOwnProperty(id)) {
                Logger.log('PluginManager', 'Attempted to reload a plugin that is not loaded: ' + id, 'warn');
                return null;
            }

            if (Plugins[id].internal.storage.getSetting('enabled')) Plugins[id].onStop();

            return this.loadPluginv2(Plugins[id].internal.path, true);
        }
    }, {
        key: 'startPlugin',
        value: function startPlugin(id) {
            if (!Plugins.hasOwnProperty(id)) {
                Logger.log('PluginManager', 'Attempted to start a plugin that is not loaded: ' + id, 'err');
                return;
            }

            if (!Plugins[id].onStart()) return false;
            Plugins[id].internal.storage.setSetting('enabled', true);
            return true;
        }
    }, {
        key: 'stopPlugin',
        value: function stopPlugin(id) {
            if (!Plugins.hasOwnProperty(id)) {
                Logger.log('PluginManager', 'Attempted to stop a plugin that is not loaded: ' + id, 'err');
                return;
            }

            if (!Plugins[id].onStop()) return false;
            Plugins[id].internal.storage.setSetting('enabled', false);
            return true;
        }
    }, {
        key: 'plugins',
        get: function get() {
            return Plugins;
        }
    }]);

    return PluginManager;
}();

module.exports = PluginManager;

/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Renderer Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var React = __webpack_require__(20);
var ReactDOM = __webpack_require__(21);
var $ = __webpack_require__(19);

var Renderer = function () {
    function Renderer() {
        _classCallCheck(this, Renderer);
    }

    //Get react instance


    _createClass(Renderer, null, [{
        key: 'rawRender',


        //Render a raw component
        value: function rawRender() {
            ReactDOM.render.apply(ReactDOM, arguments);
        }

        //Main render method, returns the root element, component and removal function

    }, {
        key: 'render',
        value: function render(root, component) {
            var re = ReactDOM.render(component, root[0]);
            return {
                "root": root,
                "element": re,
                "remove": function remove() {
                    return root.remove();
                }
            };
        }

        //Insert root element before supplied selector

    }, {
        key: 'insertBefore',
        value: function insertBefore(selector, root, component) {
            root.insertBefore($(selector));
            return this.render(root, component);
        }

        //Insert root element after supplied selector

    }, {
        key: 'insertAfter',
        value: function insertAfter(selector, root, component) {
            root.insertAfter($(selector));
            return this.render(root, component);
        }

        //Append root element to supplied selector

    }, {
        key: 'append',
        value: function append(selector, root, component) {
            $(selector).append(root);
            return this.render(root, component);
        }

        //Append root element to supplied selector

    }, {
        key: 'appendTo',
        value: function appendTo(selector, root, component) {
            root.appendTo($(selector));
            return this.render(root, component);
        }

        //Prepend root element to supplied selector

    }, {
        key: 'prepend',
        value: function prepend(selector, root, component) {
            $(selector).prepend(root);
            return this.render(root, component);
        }

        //Prepend root element to supplied selector

    }, {
        key: 'prependTo',
        value: function prependTo(selector, root, component) {
            $(selector).prepend(root);
            return this.render(root, component);
        }

        //Replace supplied selector with root

    }, {
        key: 'replaceWith',
        value: function replaceWith(selector, root, component) {
            $(selector).replaceWith(root);
            return this.render(root, component);
        }
    }, {
        key: 'react',
        get: function get() {
            return React;
        }

        //Get react-dom instance

    }, {
        key: 'reactDom',
        get: function get() {
            return ReactDOM;
        }
    }]);

    return Renderer;
}();

module.exports = Renderer;

/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Plugin Api
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
*/

var Logger = __webpack_require__(9);

var PluginApi = function () {
    function PluginApi(props) {
        _classCallCheck(this, PluginApi);

        this.props = props;
    }

    _createClass(PluginApi, [{
        key: 'log',
        value: function log(message, level) {
            Logger.log(this.props.name, message, level);
        }
    }]);

    return PluginApi;
}();

module.exports = PluginApi;

/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * BetterDiscord Plugin Export
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Plugin = __webpack_require__(35);
var PluginStorage = __webpack_require__(36);
var PluginApi = __webpack_require__(33);

module.exports = {
  Plugin: Plugin,
  PluginStorage: PluginStorage,
  PluginApi: PluginApi
};

/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Plugin Base Class
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var Plugin = function () {
    function Plugin(props) {
        _classCallCheck(this, Plugin);

        this.props = props;
    }

    _createClass(Plugin, [{
        key: "authors",
        get: function get() {
            return this.props.authors;
        }
    }, {
        key: "version",
        get: function get() {
            return this.props.version;
        }
    }, {
        key: "name",
        get: function get() {
            return this.props.name;
        }
    }, {
        key: "description",
        get: function get() {
            return this.props.description;
        }
    }, {
        key: "reloadable",
        get: function get() {
            return this.props.reloadable;
        }
    }, {
        key: "permissions",
        get: function get() {
            return this.props.permissions;
        }
    }]);

    return Plugin;
}();

module.exports = Plugin;

/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Plugin Storage
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
*/

var Utils = __webpack_require__(6);

var PluginStorage = function () {
    function PluginStorage(path, defaults) {
        _classCallCheck(this, PluginStorage);

        this.path = path + '/settings.json';
        this.defaultConfig = defaults;
        this.load();
    }

    _createClass(PluginStorage, [{
        key: 'load',
        value: function load() {
            var self = this;
            self.settings = self.defaultConfig;

            var loadSettings = Utils.tryParse(Utils.readFileSync(self.path));

            if (loadSettings) {
                Object.keys(loadSettings).map(function (key) {
                    self.setSetting(key, loadSettings[key]);
                });
            }

            if (!this.getSetting('enabled')) this.setSetting('enabled', false);
        }
    }, {
        key: 'save',
        value: function save() {
            var reduced = this.settings.reduce(function (result, item) {
                result[item.id] = item.value;return result;
            }, {});
            Utils.writeFileSync(this.path, JSON.stringify(reduced));
        }
    }, {
        key: 'getSetting',
        value: function getSetting(id) {
            var setting = this.settings.find(function (setting) {
                return setting.id === id;
            });
            if (!setting) return null;
            return setting.value;
        }
    }, {
        key: 'setSetting',
        value: function setSetting(id, value) {
            var setting = this.settings.find(function (setting) {
                return setting.id === id;
            });
            if (!setting) {
                this.settings.push({ 'id': id, 'value': value });
            } else {
                setting.value = value;
            }
            this.save();
        }
    }]);

    return PluginStorage;
}();

module.exports = PluginStorage;

/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Button Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CButton = function (_Component) {
    _inherits(CButton, _Component);

    function CButton(props) {
        _classCallCheck(this, CButton);

        return _possibleConstructorReturn(this, (CButton.__proto__ || Object.getPrototypeOf(CButton)).call(this, props));
    }

    _createClass(CButton, [{
        key: 'render',
        value: function render() {
            return React.createElement(
                'div',
                { className: 'btn btn-primary' },
                this.props.text
            );
        }
    }]);

    return CButton;
}(_React.Component);

exports.default = CButton;

/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Checkbox Group Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

var _checkbox = __webpack_require__(7);

var _checkbox2 = _interopRequireDefault(_checkbox);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CCheckboxGroup = function (_Component) {
    _inherits(CCheckboxGroup, _Component);

    function CCheckboxGroup(props) {
        _classCallCheck(this, CCheckboxGroup);

        return _possibleConstructorReturn(this, (CCheckboxGroup.__proto__ || Object.getPrototypeOf(CCheckboxGroup)).call(this, props));
    }

    _createClass(CCheckboxGroup, [{
        key: 'render',
        value: function render() {
            var _this2 = this;

            return React.createElement(
                'ul',
                { className: 'checkbox-group' },
                this.props.items.map(function (value) {
                    return React.createElement(_checkbox2.default, { li: true, checked: value.checked || value.enabled, onChange: _this2.props.onChange, key: value.key, id: value.key, text: value.text, helptext: value.helptext, link: value.link });
                })
            );
        }
    }]);

    return CCheckboxGroup;
}(_React.Component);

exports.default = CCheckboxGroup;

/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord ContextMenu Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

var _contextMenuCheckbox = __webpack_require__(16);

var _contextMenuCheckbox2 = _interopRequireDefault(_contextMenuCheckbox);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CContextMenu = function (_Component) {
    _inherits(CContextMenu, _Component);

    function CContextMenu(props) {
        _classCallCheck(this, CContextMenu);

        return _possibleConstructorReturn(this, (CContextMenu.__proto__ || Object.getPrototypeOf(CContextMenu)).call(this, props));
    }

    _createClass(CContextMenu, [{
        key: 'render',
        value: function render() {
            return React.createElement(
                'div',
                { className: 'context-menu', style: { top: this.props.top, left: this.props.left } },
                this.props.items.map(function (value) {
                    if (value.type === 'toggle') {
                        return React.createElement(
                            'div',
                            { key: value.key, className: 'item item-toggle' },
                            React.createElement(
                                'div',
                                { className: 'label' },
                                value.text
                            ),
                            React.createElement(_contextMenuCheckbox2.default, null)
                        );
                    }
                    return React.createElement(
                        'div',
                        { onClick: value.onClick, key: value.key, className: 'item' },
                        React.createElement(
                            'span',
                            null,
                            value.text
                        ),
                        React.createElement('div', { className: 'hint' })
                    );
                })
            );
        }
    }]);

    return CContextMenu;
}(_React.Component);

exports.default = CContextMenu;

/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Plugin Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

var _checkbox = __webpack_require__(7);

var _checkbox2 = _interopRequireDefault(_checkbox);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CPluginSettings = function (_Component) {
    _inherits(CPluginSettings, _Component);

    function CPluginSettings(props) {
        _classCallCheck(this, CPluginSettings);

        return _possibleConstructorReturn(this, (CPluginSettings.__proto__ || Object.getPrototypeOf(CPluginSettings)).call(this, props));
    }

    _createClass(CPluginSettings, [{
        key: 'render',
        value: function render() {
            return React.createElement(
                'div',
                null,
                'Not yet implemented'
            );
        }
    }]);

    return CPluginSettings;
}(_React.Component);

var CPlugin = function (_Component2) {
    _inherits(CPlugin, _Component2);

    function CPlugin(props) {
        _classCallCheck(this, CPlugin);

        var _this2 = _possibleConstructorReturn(this, (CPlugin.__proto__ || Object.getPrototypeOf(CPlugin)).call(this, props));

        _this2.reload = _this2.reload.bind(_this2);
        _this2.onChange = _this2.onChange.bind(_this2);
        _this2.setInitialState();
        return _this2;
    }

    _createClass(CPlugin, [{
        key: 'setInitialState',
        value: function setInitialState() {
            this.state = {
                'permissions': false,
                'checked': this.props.Plugin.internal.storage.getSetting('enabled')
            };
        }
    }, {
        key: 'render',
        value: function render() {
            var _this3 = this;

            var Plugin = this.props.Plugin;


            return React.createElement(
                'div',
                { className: 'bd-plugin-container' },
                React.createElement(
                    'div',
                    { className: 'bd-plugin-info' },
                    React.createElement(
                        'div',
                        { className: 'bd-plugin-name' },
                        Plugin.name + ' v' + Plugin.version + ' by ' + Plugin.authors.join(", ")
                    ),
                    React.createElement(
                        'div',
                        { className: 'scroller-wrap fade bd-plugin-description' },
                        React.createElement(
                            'div',
                            { className: 'scroller' },
                            Plugin.description
                        )
                    )
                ),
                React.createElement(
                    'div',
                    { className: 'bd-plugin-controls' },
                    React.createElement(_checkbox2.default, { checked: Plugin.internal.storage.getSetting('enabled'), onChange: this.onChange, id: Plugin.name, text: 'Enabled' }),
                    Plugin.reloadable && React.createElement(
                        'div',
                        { className: 'btn btn-primary', onClick: function onClick() {
                                return _this3.reload(Plugin.name);
                            } },
                        'Reload'
                    ),
                    React.createElement(
                        'div',
                        { className: 'btn btn-primary' },
                        'Settings'
                    ),
                    React.createElement(
                        'div',
                        { className: 'btn btn-primary' },
                        'Uninstall'
                    )
                ),
                this.state.settings && React.createElement(CPluginSettings, null)
            );
        }
    }, {
        key: 'reload',
        value: function reload(id) {
            var PluginManager = this.props.PluginManager;

            PluginManager.reloadPlugin(id);
        }
    }, {
        key: 'onChange',
        value: function onChange(id, checked) {
            var _props = this.props,
                PluginManager = _props.PluginManager,
                Plugin = _props.Plugin;


            if (checked) {
                var success = PluginManager.startPlugin(id);
                return success;
            } else {
                var _success = PluginManager.stopPlugin(id);
                return _success;
            }
        }
    }]);

    return CPlugin;
}(_React.Component);

exports.default = CPlugin;

/*
if (Plugin.permissions.length >= 1 && checked) {
            this.setState({
                'permissions': true,
                'checked': false
            });
            return;
        }
*/

/*

{this.state.permissions &&
    <div className="bd-plugin-permissions">
        <div className="bd-plugin-permissions-inner">
        <h3>{Plugin.name} requests the following permissions</h3>
        <div className="scroller-wrap fade">
            <div className="scroller">
                {Plugin.permissions.map(permission => {
                    return (
                        <div className="bd-plugin-permission">
                            <h2>Send Messages</h2>
                            <span>Send messages on your behalf</span>
                        </div>
                        )
                })}
            </div>
        </div>
        <div className="bd-plugin-permissions-controls">
            <div className="btn btn-primary" style={{marginLeft: "10px"}}>Enable</div>
            <div className="btn btn-primary">Back</div>
        </div>
        </div>
    </div>
}
*/

/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Plugin List Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

var _plugin = __webpack_require__(40);

var _plugin2 = _interopRequireDefault(_plugin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CPluginList = function (_Component) {
    _inherits(CPluginList, _Component);

    function CPluginList(props) {
        _classCallCheck(this, CPluginList);

        var _this = _possibleConstructorReturn(this, (CPluginList.__proto__ || Object.getPrototypeOf(CPluginList)).call(this, props));

        _this.setInitialState();
        _this.refreshLocal = _this.refreshLocal.bind(_this);
        _this.refreshOnline = _this.refreshOnline.bind(_this);
        return _this;
    }

    _createClass(CPluginList, [{
        key: 'setInitialState',
        value: function setInitialState() {
            this.state = {
                'local': {
                    'refreshing': false,
                    'plugins': this.props.PluginManager.plugins
                },
                refreshingOnline: false
            };
        }
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            var localPlugins = this.state.local.plugins;

            return React.createElement(
                'div',
                { className: 'control-groups bd-plugins' },
                React.createElement(
                    'div',
                    { className: 'tab-bar TOP' },
                    React.createElement(
                        'div',
                        { className: 'tab-bar-item selected' },
                        'Installed',
                        React.createElement('div', { className: this.state.local.refreshing ? "bd-tab-refresh animate" : "bd-tab-refresh", onClick: this.refreshLocal })
                    ),
                    React.createElement(
                        'div',
                        { className: 'tab-bar-item' },
                        'Online',
                        React.createElement('div', { className: 'bd-tab-refresh', onClick: this.refreshOnline })
                    )
                ),
                Object.keys(localPlugins).map(function (key, index, arr) {
                    return React.createElement(_plugin2.default, { PluginManager: _this2.props.PluginManager, key: index, Plugin: localPlugins[key] });
                })
            );
        }
    }, {
        key: 'refreshLocal',
        value: function refreshLocal() {
            var self = this;
            this.setState({
                'local': {
                    'refreshing': true,
                    'plugins': this.state.local.plugins
                }
            });

            var PluginManager = self.props.PluginManager;


            PluginManager.loadPlugins(function (plugins) {
                self.setState({
                    'local': {
                        'refreshing': false,
                        'plugins': plugins
                    }
                });
            });
        }
    }, {
        key: 'refreshOnline',
        value: function refreshOnline() {
            this.setState({
                refreshingOnline: true
            });
        }
    }]);

    return CPluginList;
}(_React.Component);

exports.default = CPluginList;

/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Protip Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

var _link = __webpack_require__(18);

var _link2 = _interopRequireDefault(_link);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CProTip = function (_Component) {
    _inherits(CProTip, _Component);

    function CProTip(props) {
        _classCallCheck(this, CProTip);

        return _possibleConstructorReturn(this, (CProTip.__proto__ || Object.getPrototypeOf(CProTip)).call(this, props));
    }

    _createClass(CProTip, [{
        key: 'render',
        value: function render() {
            return React.createElement(
                'div',
                { 'data-bd': 'protip', className: 'protip' },
                React.createElement(
                    'div',
                    { className: 'tip' },
                    this.props.title,
                    this.props.link !== undefined && React.createElement(_link2.default, { id: this.props.link.key, text: this.props.link.text, onClick: this.props.link.onClick }),
                    this.props.links !== undefined && this.props.links.map(function (value, index, array) {
                        return React.createElement(
                            'span',
                            { key: value.key },
                            React.createElement(_link2.default, { style: { float: "right" }, id: value.key, text: value.text, onClick: value.onClick }),
                            index !== array.length - 1 && React.createElement(
                                'span',
                                { style: { float: "right" } },
                                '-'
                            )
                        );
                    })
                )
            );
        }
    }]);

    return CProTip;
}(_React.Component);

exports.default = CProTip;

/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Settings Panel Component
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _React = __webpack_require__(1);

var _checkbox = __webpack_require__(7);

var _checkbox2 = _interopRequireDefault(_checkbox);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _require = __webpack_require__(0),
    React = _require.React;

var CSettingsPanel = function (_Component) {
    _inherits(CSettingsPanel, _Component);

    function CSettingsPanel(props) {
        _classCallCheck(this, CSettingsPanel);

        var _this = _possibleConstructorReturn(this, (CSettingsPanel.__proto__ || Object.getPrototypeOf(CSettingsPanel)).call(this, props));

        _this.setInitialState();
        _this.switchTab = _this.switchTab.bind(_this);
        return _this;
    }

    _createClass(CSettingsPanel, [{
        key: 'setInitialState',
        value: function setInitialState() {
            this.state = {
                activeTab: this.props.initialTab
            };
        }
    }, {
        key: 'render',
        value: function render() {
            var _this2 = this;

            return React.createElement(
                'div',
                { className: 'scroller-wrap' },
                React.createElement(
                    'div',
                    { className: 'scroller settings-wrapper settings-panel user-settings-text-chat' },
                    React.createElement(
                        'div',
                        { className: 'tab-bar TOP' },
                        this.props.tabs.map(function (value) {
                            var cn = _this2.state.activeTab === value.key ? "tab-bar-item selected" : "tab-bar-item";
                            return React.createElement(
                                'div',
                                { key: value.key, onClick: function onClick() {
                                        value.onClick ? value.onClick(value.key) : _this2.switchTab(value.key);
                                    }, className: cn },
                                value.text
                            );
                        }),
                        this.props.topbuttons !== undefined && React.createElement(
                            'div',
                            { style: { position: "absolute", top: "24px", right: "20px" } },
                            this.props.topbuttons.map(function (value) {
                                return React.createElement(
                                    'div',
                                    { key: value.key, style: { height: "15px", fontSize: "10px", padding: "3px 6px" }, onClick: value.onClick, className: 'btn btn-primary' },
                                    value.text
                                );
                            })
                        )
                    ),
                    this.props.content[this.state.activeTab],
                    this.props.footer !== undefined && this.props.footer
                )
            );
        }
    }, {
        key: 'switchTab',
        value: function switchTab(tab) {
            this.setState({
                activeTab: tab
            });
        }
    }]);

    return CSettingsPanel;
}(_React.Component);

exports.default = CSettingsPanel;

/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _components = __webpack_require__(17);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * BetterDiscord Context Menu
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
*/

var _require = __webpack_require__(3),
    Events = _require.Events,
    Renderer = _require.Renderer,
    CssEditor = _require.CssEditor;

var _require2 = __webpack_require__(0),
    React = _require2.React,
    ReactDOM = _require2.ReactDOM,
    $ = _require2.$;

var ContextMenu = function () {
    function ContextMenu() {
        _classCallCheck(this, ContextMenu);

        var self = this;
        Events.on('context-menu', function (contextMenu) {
            $(".context-menu .item").on("mouseover", function () {
                $("[data-bd=context-menu-sub]").remove();
            });
            self.button = $("<div/>", {
                class: "item item-subMenu",
                'data-bd': "context-menu",
                hover: function hover() {
                    return self.render();
                }
            }).append($("<span/>", {
                text: "BetterDiscord"
            }));
            contextMenu.append(self.button);
        });
    }

    _createClass(ContextMenu, [{
        key: 'render',
        value: function render() {
            var self = this;
            var $cmpos = $(".context-menu").first().position();

            var _self$button$position = self.button.position(),
                top = _self$button$position.top,
                left = _self$button$position.left;

            var items = [{
                "key": "voice-disconnect",
                "text": "Voice Disconnect",
                "type": "toggle"
            }, {
                "key": "developer-mode",
                "text": "Developer Mode",
                "type": "toggle"
            }, {
                "key": "css-editor",
                "text": "CSS Editor",
                "type": "button",
                "onClick": function onClick() {
                    CssEditor.open();
                }
            }];

            var contexMenu = React.createElement(_components.CContextMenu, { top: top + $cmpos.top + 'px', left: left + $cmpos.left + 'px', items: items });
            var subMenu = Renderer.append("[data-bd=context-menu]", $("<div/>", { "data-bd": "context-menu-sub" }), contexMenu);
        }
    }]);

    return ContextMenu;
}();

module.exports = new ContextMenu();

/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Settings Panel Module
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _components = __webpack_require__(17);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var _require = __webpack_require__(0),
    React = _require.React,
    ReactDOM = _require.ReactDOM,
    $ = _require.$;

var _require2 = __webpack_require__(3),
    Events = _require2.Events,
    Settings = _require2.Settings,
    Renderer = _require2.Renderer,
    CssEditor = _require2.CssEditor,
    PluginManager = _require2.PluginManager;

var SettingsPanel = function () {
    function SettingsPanel() {
        _classCallCheck(this, SettingsPanel);

        var self = this;

        self.initUi();

        Events.on('user-settings-modal', function (e) {
            self.render();
        });
    }

    _createClass(SettingsPanel, [{
        key: 'initUi',
        value: function initUi() {
            var self = this;

            self.ui = {
                "root": $("<div/>", { class: "settings-inner", css: { display: "none" } }),
                "button": $("<div/>", { "data-bd": "tbi-settings", class: "tab-bar-item", click: self.showSettings.bind(self) }).append($("<span/>", { text: "Better" })).append($("<span/>", { text: "Discord" })),
                "footer": {
                    "link": { "key": "splink", "text": "Jiiks", "onClick": function onClick(key) {
                            window.open("https://github.com/Jiiks", "_blank");
                        } },
                    "links": [{ "key": "splinks0", "text": "BetterDiscord.net", "onClick": function onClick(key) {
                            window.open("https://betterdiscord.net", "_blank");
                        } }, { "key": "splinks1", "text": "changelog", "onClick": function onClick(key) {
                            console.log("show changelog");
                        } }]
                },
                "content": {
                    "core": React.createElement(
                        'div',
                        { className: 'control-groups' },
                        React.createElement(
                            'div',
                            { className: 'control-group' },
                            React.createElement(_components.CCheckboxGroup, { items: Settings.getCoreSettings, onChange: function onChange(key, checked) {
                                    return self.onChange("core", key, checked);
                                } })
                        )
                    ),
                    "ui": React.createElement(
                        'div',
                        { className: 'control-groups' },
                        React.createElement(
                            'div',
                            { className: 'control-group' },
                            React.createElement(_components.CCheckboxGroup, { items: Settings.getUiSettings, onChange: function onChange(key, checked) {
                                    return self.onChange("ui", key, checked);
                                } })
                        )
                    ),
                    "emotes": React.createElement(
                        'div',
                        { className: 'control-groups' },
                        React.createElement(
                            'div',
                            { className: 'control-group' },
                            React.createElement(_components.CCheckboxGroup, { items: Settings.getEmoteSettings, onChange: function onChange(key, checked) {
                                    return self.onChange("emotes", key, checked);
                                } })
                        )
                    ),
                    "plugins": React.createElement(_components.CPluginList, { PluginManager: PluginManager })
                },
                "tabs": [{ "key": "core", "text": "Core" }, { "key": "ui", "text": "UI" }, { "key": "emotes", "text": "Emotes" }, { "key": "plugins", "text": "Plugins" }, { "key": "themes", "text": "Themes" }, { "key": "security", "text": "Security" }],
                "topbuttons": [{ "key": "css", "text": "CSS Editor", onClick: function onClick(key) {
                        return self.openCssEditor();
                    } }]
            };
        }
    }, {
        key: 'refreshLocalPlugins',
        value: function refreshLocalPlugins(cb) {
            PluginLoader.loadPlugins(function (plugins) {
                return cb(plugins);
            });
        }
    }, {
        key: 'openCssEditor',
        value: function openCssEditor() {
            CssEditor.open();
        }
    }, {
        key: 'onChange',
        value: function onChange(sub, key, checked) {
            Settings.setSetting(sub, key, checked);
            return true;
        }
    }, {
        key: 'showSettings',
        value: function showSettings() {
            var self = this;
            $(".tab-bar.SIDE .tab-bar-item").removeClass("selected");
            self.ui.button.addClass("selected");
            $(".settings-inner").hide();
            self.ui.root.show();
        }
    }, {
        key: 'hideSettings',
        value: function hideSettings() {
            var self = this;
            $(".form .settings-right .settings-inner").first().show();
            self.ui.root.hide();
            self.ui.button.removeClass("selected");
        }
    }, {
        key: 'toggleSetting',
        value: function toggleSetting(sub, key, checked) {
            Settings.setSetting(sub, key, checked);
        }
    }, {
        key: 'render',
        value: function render() {
            var self = this;
            $(".tab-bar.SIDE .tab-bar-item").on("click", self.hideSettings.bind(self));
            self.ui.button.removeClass("selected");
            self.ui.root.hide();
            self.ui.button.insertBefore($(".change-log-button-container"));

            var footer = React.createElement(_components.CProTip, { title: 'BetterDiscord v0.3.0-DEVELOPER PREVIEW 1 by', link: self.ui.footer.link, links: self.ui.footer.links });
            var settingsPanel = React.createElement(_components.CSettingsPanel, { initialTab: 'core', content: self.ui.content, tabs: self.ui.tabs, footer: footer, topbuttons: self.ui.topbuttons });
            Renderer.insertBefore(".form .settings-right .settings-actions", self.ui.root, settingsPanel);
        }
    }]);

    return SettingsPanel;
}();

module.exports = SettingsPanel;

/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord jQuery vendor
 * Exports jQuery to be used in other classes
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



var momentInstance = window._bd.moment;

module.exports = momentInstance;

/***/ }),
/* 47 */
/***/ (function(module, exports) {

module.exports = window.require('events');

/***/ }),
/* 48 */
/***/ (function(module, exports) {

module.exports = window.require('fs');

/***/ }),
/* 49 */
/***/ (function(module, exports) {

module.exports = window.require('react-dom');

/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * BetterDiscord Client Core
 * Copyright (c) 2015-present Jiiks - https://jiiks.net
 * All rights reserved.
 * https://github.com/Jiiks/BetterDiscordApp - https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree. 
 */



function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var _require = __webpack_require__(3),
    Observer = _require.Observer,
    Settings = _require.Settings,
    IPC = _require.IPC,
    Events = _require.Events,
    PluginManager = _require.PluginManager,
    Utils = _require.Utils,
    Logger = _require.Logger;

var Api = __webpack_require__(23);

var _require2 = __webpack_require__(24),
    SettingsPanel = _require2.SettingsPanel,
    ContextMenu = _require2.ContextMenu;

var _require3 = __webpack_require__(0),
    $ = _require3.$;

var BDCore = function BDCore() {
        _classCallCheck(this, BDCore);

        Settings.init();

        var css = Utils.readFileSync(Settings.settings.dataPath + '/betterdiscord.css');

        $("head").append('<style>' + css + '</style>');

        PluginManager.init();

        window.onbeforeunload = function (e) {
                IPC.send({ "command": "reset" });
        };

        Observer.observe({ 'childList': true, 'subtree': true });

        var settingsPanel = new SettingsPanel();
};

new BDCore();

/***/ })
/******/ ]);