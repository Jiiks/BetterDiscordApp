const { BetterDiscord } = require('./main');

module.exports = new BetterDiscord({ mainWindow: null });