'use strict';

const BDEmoteModule = require('./emotemodule');

module.exports = {
    BDEmoteModule: BDEmoteModule
}