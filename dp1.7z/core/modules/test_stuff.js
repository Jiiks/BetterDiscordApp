(() => {
    let _erl = require("erlpack");
    let onmessage = _bd_fastHook.ws.onmessage;
    _bd_fastHook.ws.onmessage = function(e) {
        let unpacked = null;
        let packed = new Buffer(e.data, 'binary');
        try {
            unpacked = _erl.unpack(packed);
        }catch(err) {

        }
        console.log(unpacked);
        //Pass the event to the original handler
        onmessage(e);
    }

    let onclose = _bd_fastHook.ws.onclose;
    _bd_fastHook.ws.onclose = function(e) {
        window._bd_fastHook = window._ws;
        console.log("ONCLOSE");
        onclose(e);
    }

    let onopen = _bd_fastHook.ws.onopen;
    _bd_fastHook.ws.onopen = function(e) {
        console.log("ONOPEN");
        onopen(e);
    }

})();

_bd_fastHook.ws.send({"op": 3, "d": { "game": { "name": "test" } }})